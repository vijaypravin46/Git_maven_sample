package com.htc.mapping;

class ArrayRotation {

    public static void main(String[] args)
    {
        int arr[] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
        int n = arr.length;
        int k = 5;
        
        int[] temp;
         
        temp =  new int[n];
        
        for(int i=0; i<k; i++)
            temp[i] = arr[i];
    
        int x = k;
        for(int i=0; x < n; i++){
            arr[i] = arr[x++];
        }
        
        x = 0;
    
        for(int i=n-k; i<n; i++)
            arr[i] = temp[x++];
    
   
        for (int i = 0; i < 9; i++)
            System.out.print(arr[i] + " ");
    }
}
/*
{    
 int n1=0,n2=1,n3,i,count=20;    
 System.out.print(n1+" "+n2);//printing 0 and 1        
 for(i=2;i<count;++i)//loop starts from 2 because 0 and 1 are already printed    
 {    
  n3=n1+n2;    
  System.out.print(" "+n3);    
  n1=n2;    
  n2=n3;    
 }
}
}
    
 // Method 1
    // To right rotate array of size n by d
    void rightRotate(int arr[], int d, int n)
    {
        // Iterating till we want
        for (int i = n; i > d; i--)
 
            // Recursively calling
            rightRotatebyOne(arr, n);
    }
 
    // Method 2
    // To rotate array by 1
    void rightRotatebyOne(int arr[], int n)
    {
        int i, temp;
        temp = arr[0];
        for (i = 0; i < n - 1; i++)
            arr[i] = arr[i + 1];
        arr[i] = temp;
    }
 
    // Method 3
    // To print an array
    void printArray(int arr[], int n)
    {
        for (int i = 0; i < n; i++)
            System.out.print(arr[i] + " ");
    }
 
    // Method 4
    // Main driver method
    public static void main(String[] args)
    {
        // Creating an object of class inside main()
        ArrayRotation rotate = new ArrayRotation();
 
        // Custom input elements
        int arr[] = { 1, 2, 3, 4, 5 };
 
        // Calling method 1 and 2
        rotate.rightRotate(arr, 2, arr.length);
        rotate.printArray(arr, arr.length);
    }
}*/
